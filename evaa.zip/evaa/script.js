var addToCartButtons = document.getElementsByClassName('add-to-cart-btn');
var cartItemsContainer = document.getElementById('cart-items');
var buyButton = document.getElementById('buy-button');
var thankYouMessage = document.getElementById('thank-you-message');
var reviewSection = document.getElementById('review-section');
var reviewTextarea = document.getElementById('review-textarea');
var submitReviewButton = document.getElementById('submit-review');
var reviewsContainer = document.getElementById('reviews-container');
var reviewsList = document.getElementById('reviews-list');

var cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
var reviews = [];

function addToCart() {
    var button = this;
    var product = button.parentNode;
    var productName = product.getElementsByTagName('h3')[0].innerText;

    button.innerHTML = 'En el carrito';
    button.className = 'added-to-cart-btn';
    button.disabled = true;
    console.log('El producto "' + productName + '" se ha agregado correctamente');

    cartItems.push(productName);
    saveCartItems();
}

function updateCart() {
    cartItemsContainer.innerHTML = '';

    for (var i = 0; i < cartItems.length; i++) {
        var cartItem = document.createElement('div');
        cartItem.innerText = cartItems[i];
        cartItemsContainer.appendChild(cartItem);
    }
}

function saveCartItems() {
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
    updateCart();
}

function buy() {
    cartItems = [];
    localStorage.removeItem('cartItems');
    updateCart();

    thankYouMessage.style.display = 'block';
    reviewSection.style.display = 'block';
}

function submitReview() {
    var review = reviewTextarea.value;
    console.log('Reseña enviada:', review);
    reviews.push(review);
    renderReviews();
    reviewTextarea.value = '';
}

function renderReviews() {
    reviewsList.innerHTML = '';
    for (var i = 0; i < reviews.length; i++) {
        var reviewItem = document.createElement('li');
        reviewItem.innerText = reviews[i];
        reviewsList.appendChild(reviewItem);
    }
    reviewsContainer.style.display = 'block';
}

for (var i = 0; i < addToCartButtons.length; i++) {
    addToCartButtons[i].addEventListener('click', addToCart);
}

buyButton.addEventListener('click', buy);
submitReviewButton.addEventListener('click', submitReview);

updateCart();
